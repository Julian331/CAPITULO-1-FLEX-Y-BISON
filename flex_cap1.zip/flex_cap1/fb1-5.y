%{
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void yyerror(const char *s);
int yylex(void);
%}

%token NUMBER

%%

input:
    /* vacío */
  | input line
  ;

line:
    '\n'
  | exp '\n'        { printf("= %d\n", $1); }
  | error '\n'      { yyerrok; }
  ;


exp:
    exp '+' term   { $$ = $1 + $3; }
  | exp '-' term   { $$ = $1 - $3; }
  | term
  ;

term:
    term '*' power   { $$ = $1 * $3; }
  | term '/' power   { $$ = $1 / $3; }
  | power
  ;

power:
    factor '^' power   { $$ = pow($1, $3); }
  | factor
  ;

factor:
    NUMBER
  | '(' exp ')'   { $$ = $2; }
  ;

%%

void yyerror(const char *s)
{
    fprintf(stderr, "Error: %s\n", s);
}

int main(void)
{
    return yyparse();
}
